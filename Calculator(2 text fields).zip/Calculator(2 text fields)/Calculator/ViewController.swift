//
//  ViewController.swift
//  Calculator
//
//  Created by m on 7/23/18.
//  Copyright © 2018 WzyoU. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var BTN_desig1: UIButton!
    @IBOutlet weak var BTN_desig2: UIButton!
    @IBOutlet weak var BTN_desig3: UIButton!
    @IBOutlet weak var BTN_desig4: UIButton!
    @IBOutlet weak var BTN_desig5: UIButton!
    @IBOutlet weak var BTN_desig6: UIButton!
    @IBOutlet weak var BTN_desig7: UIButton!
    @IBOutlet weak var BTN_desig8: UIButton!
    @IBOutlet weak var BTN_desig9: UIButton!
    @IBOutlet weak var BTN_desig0: UIButton!
    @IBOutlet weak var BTN_desig_dot: UIButton!
    
    
    @IBOutlet weak var BTN_desig_plus: UIButton!
    @IBOutlet weak var BTN_desig_minus: UIButton!
    @IBOutlet weak var BTN_desig_product: UIButton!
    @IBOutlet weak var BTN_desig_moduls: UIButton!
    @IBOutlet weak var BTN_desig_divide: UIButton!
    @IBOutlet weak var BTN_desig_result: UIButton!
    @IBOutlet weak var txt_num1: UITextField!
    @IBOutlet weak var txt_num2: UITextField!
    
    @IBOutlet weak var lbl_Res: UILabel!
    //*************************************
   
    var txt1_string = ""
    var txt2_string = ""
    var Result: Double = 0.0
    var oper = ""
    
    
    //**************************************
    override func viewDidLoad() {
        super.viewDidLoad()
      BTN_desig_plus.layer.cornerRadius = 10
        BTN_desig_plus.clipsToBounds = true
        BTN_desig_product.layer.cornerRadius = 10
        BTN_desig_product.clipsToBounds = true
        BTN_desig_minus.layer.cornerRadius = 10
        BTN_desig_minus.clipsToBounds = true
        BTN_desig_moduls.layer.cornerRadius = 10
        BTN_desig_moduls.clipsToBounds = true
        BTN_desig_divide.layer.cornerRadius = 10
        BTN_desig_divide.clipsToBounds = true
        BTN_desig_result.layer.cornerRadius = 10
        BTN_desig_result.clipsToBounds = true
        txt_num2.text! = ""
        txt_num1.text! = ""
        lbl_Res.text! = "0.0"
        
    }

    @IBAction func Plus(_ sender: UIButton) {
    operation(operators: BTN_desig_plus)
    }
    @IBAction func Minus(_ sender: UIButton) {
    operation(operators: BTN_desig_minus)
        
    }
    @IBAction func Divide(_ sender: UIButton) {
    operation(operators: BTN_desig_divide)
    }
    @IBAction func Product(_ sender: UIButton) {
     operation(operators: BTN_desig_product)
    }
    
    @IBAction func Moduls(_ sender: UIButton) {
        operation(operators: BTN_desig_moduls)
        
    }
    @IBAction func seven(_ sender: Any) {
        
        strings(number: BTN_desig7)
    }
    
    @IBAction func eight(_ sender: Any) {
        strings(number: BTN_desig7)
        
    }
    
    @IBAction func nine(_ sender: Any) {
        strings(number: BTN_desig9)
        
    }
    
    @IBAction func four(_ sender: Any) {
        strings(number: BTN_desig4)
    }
    
    @IBAction func five(_ sender: Any) {
        strings(number: BTN_desig5)
    }
    
    @IBAction func six(_ sender: Any) {
        strings(number: BTN_desig6)
    }
    
    @IBAction func one(_ sender: Any) {
        strings(number: BTN_desig1)
    }
    
    @IBAction func tow(_ sender: Any) {
        strings(number: BTN_desig2)
    }
    
    @IBAction func three(_ sender: Any) {
        strings(number: BTN_desig3)
    }
    
    @IBAction func zero(_ sender: Any) {
        strings(number: BTN_desig0)
    }
    
    @IBAction func dot(_ sender: Any) {
        strings(number: BTN_desig_dot)
        
    }
    
    @IBAction func clear(_ sender: Any) {
        txt_num1.text! = ""
        txt_num1.text! = ""
        lbl_Res.text! = "0.0"
        
    }
    
    
    @IBAction func Result(_ sender: UIButton) {
        if txt_num1.text == "" && txt_num2.text == ""
        {
            alert(title1: "Error",message: "Missing number1 and number2",title2: "OK")
        }
           
         else if txt_num1.text == ""
        {
           alert(title1: "Error",message: "Missing number1 ",title2: "OK")
        }
        else if txt_num2.text == ""
        {
            alert(title1: "Error",message: "Missing number2 ",title2: "OK")
        }
        else if oper == ""
        {
            
            alert(title1: "Missing operator",message: "select the operator",title2: "OK")
        }
        else
        {
            let one = Double(txt_num1.text!)
            let tow = Double(txt_num2.text!)
            
            switch oper
            {
            case "+":
                Result = one! + tow!
                break
            case "-":
                 Result = one! - tow!
                break
            case "%":
                 Result = remainder(one!, tow!)
                break
            case "*":
                 Result = one! * tow!
                break
            case "/":
                 Result = one! / tow!
                break
                
            default:
                return
            }
            lbl_Res.text = "\(Result)"
        }
   
        
        
    }
    
    func alert(title1: String,message: String,title2: String)
    {
        let myalert=UIAlertController(title: title1, message: message, preferredStyle: .alert)
        let myaction=UIAlertAction(title: title2, style: .cancel, handler: nil)
        myalert.addAction(myaction)
        present(myalert, animated: true, completion: nil)
    }
    func operation(operators: UIButton)
    {
        oper = operators.currentTitle!
        
        
    }
    func strings(number: UIButton)
    {
        if txt_num1.isTouchInside == true
        {
        
          txt_num1.text! += number.currentTitle!
            print("im txt one  \(txt_num1.isTouchInside)")
            
        }
        else if txt_num2.isTouchInside == true
        {
           txt_num2.text! += number.currentTitle!
           print("im txt tow  \(txt_num2.isTouchInside)")
            
        }
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
}

