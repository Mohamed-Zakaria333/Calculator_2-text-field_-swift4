#  Stack view usage
# this project is a best practise of how you using stack view
# calculator is more simple
# Auto layout support

